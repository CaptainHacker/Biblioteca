require 'test_helper'

class PrestitoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
