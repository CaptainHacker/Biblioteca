module ApplicationHelper
  include SessioniHelper
  include Pagy::Frontend
end
